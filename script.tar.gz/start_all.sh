#!/bin/bash

for service in  CentralApp Deribit_Sn InMemoryData MessageProce 
do

if pgrep $service >/dev/null 2>&1
        then
            echo $service is running.....
                        process_id1=`/bin/ps -fu $USER | grep "$service" | grep -v "grep" | awk '{print $2}'`
                        /usr/bin/pkill -9 $service
                        echo Stopping $service.....
                        echo -e "\n"
        else
                        echo All ok...
fi

done

printf "\nStarting All Services\n\n"

taskset -c 0 ./CentralApp > ./logs/CAlog_$(date +%d-%h-%y_%H-%M-%S).txt 2>&1 & disown
                sleep 1
                if pgrep CentralApp >/dev/null 2>&1
                        then
                                echo CentralApp started...
                        else
                                echo CentralApp did not started.
                                echo Please check if file exist
                                exit 0
fi


sleep 1

printf "Starting Deribit_Snap\n\n"

if pgrep Deribit_Sn >/dev/null 2>&1
                        then
                                echo  Deribit_Snap is running...
                        else
cd Py_Deribit_Snap; ./Deribit_Snap > Log/Deribit_Snap_Log$(date +%d-%h-%y_%H-%M-%S).txt 2>&1 & disown; cd ..
                        sleep 1
                        if pgrep Deribit_Sn >/dev/null 2>&1
                        then
                                echo Deribit_Snap Started...
                        else
                                echo Deribit_Snap did not started.
                                echo Plese check if file exist
                                exit 0
                        fi
fi


printf "Starting InMemoryData\n\n"


VMA_SPEC=latency LD_PRELOAD=libvma.so nice -n -19 ./InMemoryData > ./logs/IMD_log_$(date +%d-%h-%y_%H-%M-%S).txt 2>&1 & disown
sleep 3
if pgrep InMemoryData >/dev/null 2>&1

                        then
                                echo InMemoryData started...
                        else
                                echo InMemoryData did not started.
                                echo Plese check if file exist
                                exit 0
                        fi


sleep 2

printf "Starting MessageProcessor\n\n"

./MessageProcessor > ./logs/MPlog_$(date +%d-%h-%y_%H-%M-%S).txt 2>&1  & disown
sleep 1
if pgrep MessageProce >/dev/null 2>&1

                        then
                                echo MessageProcessor started...
                        else
                                echo MessageProcessor did not started.
                                echo Plese check if file exist
                                exit 0
                        fi

sleep 1

printf "\nLog written in logs directory\n\n"

exit 0
